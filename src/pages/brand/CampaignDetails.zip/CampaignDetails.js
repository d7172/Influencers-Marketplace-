import React, { useEffect, useState } from "react";
import { Formik } from "formik";
import { personalDetailsSchema } from "../../utils/formsSchema";
import Dropdown from "../../components/Dropdown";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";

const initForm = {
    firstName: "",
    lastName: "",
    userName: "",
    email: "",
    phone: "",
    gender: "",
    whatsapp: "",
    DOB: "",
    aboutYourself: "",
    profile: {},
    cover: {},
};

export const FormError = ({ children }) => {
    return <p className="text-red-500 text-xs italic mt-1">{children}</p>;
};
export const ImgUpload = ({ children }) => {
    return <p className="text-[13px] mt-1 text-green-600">Added {children}</p>;
};

function PersonalDetails({ setSignUpStatus }) {
    const dispatch = useDispatch();
    const [personalDetails, setPersonalDetails] = useState(initForm);
    const signUpState = useSelector((state) => state.signUpState);

    useEffect(() => {
        const { first_name, last_name, user_name, email, phone, gender, whats_app, dob, about_yourself, category } =
            signUpState.personal_details;
        if (first_name.length) {
            setPersonalDetails({
                firstName: first_name,
                lastName: last_name,
                userName: user_name,
                email,
                phone: phone.contact_number,
                gender,
                whatsapp: whats_app.contact_number,
                DOB: dob,
                aboutYourself: about_yourself,
                profile: signUpState.profile_pic,
                cover: signUpState.cover_pic,
            });
        }
    }, []);
    return (
        <div className="px-8 py-5" >
            <h1 className="text-start text-2xl font-bold mb-2">Campaign Details</h1>
            <p className="w-390 inline-block text-gray-500 text-sm text-start m-auto mb-4">
                Log in to your account using email and password provided during registration.
            </p>
            <Formik
                enableReinitialize={true}
                initialValues={personalDetails}
                validationSchema={personalDetailsSchema}
                onSubmit={(values) => {
                    const data = {
                        personal_details: {
                            first_name: values.firstName,
                            last_name: values.lastName,
                            user_name: values.userName,
                            email: values.email,
                            phone: {
                                dail_code: "+91",
                                contact_number: values.phone,
                            },
                            gender: values.gender,
                            whats_app: {
                                dail_code: "+91",
                                contact_number: values.whatsapp,
                            },
                            dob: values.DOB,
                            about_yourself: values.aboutYourself,
                            category: [...signUpState.personal_details.category],
                        },
                        profile_pic: values.profile,
                        cover_pic: values.cover,
                    };
                    dispatch({ type: "UPDATE_SIGNUP_STATE", data });
                    setSignUpStatus(2);
                }}
            >
                {({ handleChange, handleSubmit, values, errors, setFieldValue, touched }) => {
                    return (
                        <div className="w-full m-auto">
                            <div className="flex flex-wrap gap-10 items-center">
                                <div className="w-[30%] ">
                                    <label className="block text-gray-700 text-sm mb-2" htmlFor="campaignTitle">
                                        Campaign Title<span className="text-red-500">*</span>
                                    </label>
                                    <input
                                        className="input-field w-full"
                                        id="firstName"
                                        type="text"
                                        value={values.firstName}
                                        onChange={handleChange("firstName")}
                                    />
                                    {errors.firstName && touched.firstName && <FormError>{errors.firstName}</FormError>}
                                </div>
                                <div className="datepicker">
                                    <label className="block text-gray-700 text-sm mb-2">
                                        Campaign Date<span className="text-red-500">*</span>{" "}
                                    </label>
                                    <input
                                        type="date"
                                        className="input-field text-gray-500 mr-8"
                                        placeholder="From"
                                        value={values.DOB}
                                        onChange={(e) => setFieldValue("DOB", e.target.value)}
                                    />
                                    {errors.DOB && touched.DOB && <FormError>{errors.DOB}</FormError>}
                                    <input
                                        type="date"
                                        className="input-field text-gray-500"
                                        placeholder="To"
                                        value={values.DOB}
                                        onChange={(e) => setFieldValue("DOB", e.target.value)}
                                    />
                                    {errors.DOB && touched.DOB && <FormError>{errors.DOB}</FormError>}
                                </div>
                                <div>
                                    <label className="form-label inline-block mb-2">
                                        About Your Campaign <span className="text-red-500">*</span>{" "}
                                    </label>
                                    <textarea
                                        className="block w-[860px] h-[148px] px-3 py-1.5 text-base font-normal text-gray-700 bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:shadow-blue-300 focus:outline-none"
                                        id="exampleFormControlTextarea1"
                                        rows="3"
                                        value={values.aboutYourself}
                                        onChange={(e) => setFieldValue("aboutYourself", e.target.value)}
                                    />
                                    {errors.aboutYourself && touched.aboutYourself && <FormError>{errors.aboutYourself}</FormError>}
                                </div>
                                <div className="w-[30%] " >
                                    <label className="block text-gray-700 text-sm mb-2" htmlFor="firstName">
                                        Campaign Strategy<span className="text-red-500">*</span>
                                    </label>
                                    <div className="w-full">
                                        <Dropdown
                                            dropdownStyle="w-full"
                                            className="w-full"
                                            label={values.gender.length ? values.gender : "Shout Out Campaing"}
                                            options={[
                                                {
                                                    label: "Shout Out Campaing",
                                                },
                                                {
                                                    label: "Shout Out Campaing",
                                                },
                                            ]}
                                            onChange={(val) => setFieldValue("gender", val.label)}
                                        />
                                        {errors.gender && touched.gender && <FormError>{errors.gender}</FormError>}
                                    </div>
                                </div>
                                <div className="w-[30%] mr-16">
                                    <label className="block text-gray-700 text-sm mb-2" htmlFor="firstName">
                                        Campaing Goal<span className="text-red-500">*</span>
                                    </label>
                                    <div className="w-full">
                                        <Dropdown
                                            dropdownStyle="w-full"
                                            className="w-full"
                                            label={values.gender.length ? values.gender : "Lead Genration"}
                                            options={[
                                                {
                                                    label: "Lead Genration",
                                                },
                                                {
                                                    label: "Lead Genration",
                                                },
                                            ]}
                                            onChange={(val) => setFieldValue("gender", val.label)}
                                        />
                                        {errors.gender && touched.gender && <FormError>{errors.gender}</FormError>}
                                    </div>
                                </div>
                                <div className="w-[30%] ">
                                    <label className="block text-gray-700 text-sm mb-2" htmlFor="firstName">
                                        Project Duration ( No of Days )<span className="text-red-500">*</span>
                                    </label>
                                    <div>
                                        <input
                                            className="input-field w-full"
                                            id="firstName"
                                            type="number"
                                            placeholder="2"
                                            value={values.firstName}
                                            onChange={handleChange("firstName")}
                                        />
                                        {errors.firstName && touched.firstName && <FormError>{errors.firstName}</FormError>}
                                    </div>
                                </div>
                                <div className="w-[30%] mr-16">
                                    <label className="block text-gray-700 text-sm mb-2" htmlFor="firstName">
                                        Age Group<span className="text-red-500">*</span>
                                    </label>
                                    <div className="flex">
                                        <input
                                            className="input-field w-390"
                                            id="firstName"
                                            type="range"
                                            min="10"
                                            max="50"
                                            value={values.firstName}
                                            onChange={handleChange("firstName")}
                                        />
                                        {errors.firstName && touched.firstName && <FormError>{errors.firstName}</FormError>}
                                    </div>
                                </div>
                                <div className="w-[30%] " >
                                    <label className="block text-gray-700 text-sm mb-2" htmlFor="firstName">
                                        Country<span className="text-red-500">*</span>
                                    </label>
                                    <div className="w-full">
                                        <Dropdown
                                            dropdownStyle="w-full"
                                            className="w-full"
                                            label={values.gender.length ? values.gender : "India"}
                                            options={[
                                                {
                                                    label: "Australia",
                                                },
                                                {
                                                    label: "Brazil",
                                                },
                                                {
                                                    label: "Colombia",
                                                }
                                            ]}
                                            onChange={(val) => setFieldValue("gender", val.label)}
                                        />
                                        {errors.gender && touched.gender && <FormError>{errors.gender}</FormError>}
                                    </div>
                                </div>
                                <div className="w-[30%]" >
                                    <label className="block text-gray-700 text-sm mb-2" htmlFor="firstName">
                                        State<span className="text-red-500">*</span>
                                    </label>
                                    <div className="w-full">
                                        <Dropdown
                                            dropdownStyle="w-full"
                                            className="w-full"
                                            label={values.gender.length ? values.gender : "India"}
                                            options={[
                                                {
                                                    label: "Gujarat",
                                                },
                                                {
                                                    label: "Maharashtra",
                                                },
                                                {
                                                    label: "Colombia",
                                                }
                                            ]}
                                            onChange={(val) => setFieldValue("gender", val.label)}
                                        />
                                        {errors.gender && touched.gender && <FormError>{errors.gender}</FormError>}
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-gray-700 text-sm mb-2" htmlFor="firstName">
                                        Gender
                                    </label>
                                    <div>
                                        <Dropdown
                                            dropdownStyle="w-168"
                                            className="w-168"
                                            label={values.gender.length ? values.gender : "Gender"}
                                            options={[
                                                {
                                                    label: "Male",
                                                },
                                                {
                                                    label: "Female",
                                                },
                                            ]}
                                            onChange={(val) => setFieldValue("gender", val.label)}
                                        />
                                        {errors.gender && touched.gender && <FormError>{errors.gender}</FormError>}
                                    </div>
                                </div>
                                <div className="w-[30%]" >
                                    <label className="block text-gray-700 text-sm mb-2" htmlFor="firstName">
                                        Audience Interest
                                    </label>
                                    <div className="w-full">
                                        <Dropdown
                                            dropdownStyle="w-full"
                                            className="w-full"
                                            label={values.gender.length ? values.gender : "Fashion Wear"}
                                            options={[
                                                {
                                                    label: "Fashion Wear",
                                                },
                                                {
                                                    label: "Fashion Wear",
                                                },
                                            ]}
                                            onChange={(val) => setFieldValue("gender", val.label)}
                                        />
                                        {errors.gender && touched.gender && <FormError>{errors.gender}</FormError>}
                                    </div>
                                </div>
                                <div className="w-[30%]" >
                                    <label className="block text-gray-700 text-sm mb-2" htmlFor="firstName">
                                        Number of Influencer
                                    </label>
                                    <div className="w-full">
                                        <Dropdown
                                            dropdownStyle="w-full"
                                            className="w-full"
                                            label={values.gender.length ? values.gender : "1"}
                                            options={[
                                                {
                                                    label: "2",
                                                },
                                                {
                                                    label: "3",
                                                },
                                                {
                                                    label: "4",
                                                },
                                                {
                                                    label: "5",
                                                },
                                            ]}
                                            onChange={(val) => setFieldValue("gender", val.label)}
                                        />
                                        {errors.gender && touched.gender && <FormError>{errors.gender}</FormError>}
                                    </div>
                                </div>
                                <div className="w-[30%]" >
                                    <label className="block text-gray-700 text-sm mb-2" htmlFor="firstName">
                                        Number of  Followers
                                    </label>
                                    <div className="w-full">
                                        <Dropdown
                                            dropdownStyle="w-full"
                                            className="w-full"
                                            label={values.gender.length ? values.gender : "1k - 10k"}
                                            options={[
                                                {
                                                    label: "10k - 20k",
                                                },
                                                {
                                                    label: "20k - 30k",
                                                },
                                            ]}
                                            onChange={(val) => setFieldValue("gender", val.label)}
                                        />
                                        {errors.gender && touched.gender && <FormError>{errors.gender}</FormError>}
                                    </div>
                                </div>
                            </div>

                            <div className="mt-14 flex ">
                                <button
                                    type="button"
                                    className="rounded-[50px] bg-primary text-white px-4 py-2"
                                    onClick={handleSubmit}
                                >
                                    Submit Campaing
                                </button>
                                <button
                                    type="button"
                                    className="rounded-[50px] text-[#969BA0] px-4 py-2"
                                    onClick={handleSubmit}
                                >
                                    Cancle
                                </button>
                            </div>
                        </div>
                    );
                }}
            </Formik >
        </div >
    );
}

export default PersonalDetails;

export const imageSvg = (
    <svg
        className="mx-auto h-12 w-12 text-gray-400"
        stroke="currentColor"
        fill="none"
        viewBox="0 0 48 48"
        aria-hidden="true"
    >
        <path
            d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
        />
    </svg>
);
